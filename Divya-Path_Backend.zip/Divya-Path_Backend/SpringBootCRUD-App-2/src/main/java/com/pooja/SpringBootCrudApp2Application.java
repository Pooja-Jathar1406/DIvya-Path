package com.pooja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudApp2Application.class, args);
	}

}



































